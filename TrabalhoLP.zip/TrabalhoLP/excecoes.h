// Biblioteca de tratamento de exce��es
#include <iostream>
#include <string>
#include <exception>    /* bad_alloc, bad_cast, bad_exception e etc...  */
#include <stdexcept>     /* length_error, ranger_error, overflow_error, out_of_range e etc...  */
#include <ctime>
#include <fstream>
#include <vector>         // std::vector
#include<bitset>
#include<typeinfo>
using namespace std;
/*---------------
return 0 -> true
return 1 -> false
-----------------*/
/*---- Codigos --------
01 - int isDivByZero(T numero)
02 - int isNegativeSQR(T numero);
03 - int isNumber (T numero);
04 - int isWord (T palavra);
05 - int isDate (T dia, T mes, T ano);
06 -  int isIndexInvalid (T vetor[]);
07 -  T *alocation(T *ptr);
08 -  T *alocation(T *ptr);
09-void teste_invalid_argument();
10- void teste_overflow();
---------------------------*/

void registro(string logs,int codigo){
    time_t t = time(0);
    tm* now = localtime(&t);

    ofstream myfile;
    myfile.open ("logs.dat",ios::app);
    myfile << "CODIGO:"<<codigo<<"      "<<
               "DATA:"<<now->tm_mday<<"/"<<(now->tm_mon + 1)<<"/"<<(now->tm_year + 1900)<<"    "<<
               "HORA:"<<now->tm_hour<<":"<<(now->tm_min)<<":"<<(now->tm_sec)<<"          "<<
               "ERRO:"<<logs<<endl;
    myfile.close();
}

template <class T> class excecoes {
 public:
    class erro{ }; /*classe para refer�ncia na ocorrencia de erro. Utiliza-se construtor por oculta��o*/
    void Mensagem(string msg); /*Permite passar por par�metro qualquer mensagem e exibi-la para o usu�rio*/
    int isDivByZero(T numero); /*retorna true se ocorreu uma tentativa de divis�o por zero*/
    int isNegativeSQR(T numero); /*retorna true se houver tentativa de raiz negativa */
    int isNumber (T numero); /*retorna true se o valor valor passado possui apenas n�meros */
    int isWord (T palavra); /*retorna true se o valor valor passado possui apenas char */
    int isDate (T dia, T mes, T ano); /*returna true se for uma data v�lida */
    int isIndexInvalid (T vetor[], T tam, T posicao); /*returna true se tentar acessar uma posi��o de um vetor inexistente */
    T* teste_bad_alloc(T *ptr);
    void teste_invalid_argument();
    void teste_overflow();
    T *alocation(T *ptr); /*Caso n�o ocorra um erro de aloca��o de mem�ria devolve um ponteriro alocado */
    /*....demais m�todos para tratamento de erros */
 private:
    T item; /*Atributo privado que futuramente pode ser utilizado*/
};

template <class T> void excecoes<T>:: Mensagem(string msg) /*implementa��o do m�todo mensagem */
{
      cout << msg << endl;
}
///////////////////////////////////////////////////////////////////
template <class T> int excecoes<T>::isDivByZero(T numero){ /*implementa��o da verifica��o de tentativa de divisao por zero */
    int result=0;
 try {
        if (numero==0){
          throw (erro());
          result=0;
        }else{
            result=1;
        }
       // final do bloco TRY
     }catch (excecoes::erro){
          Mensagem("ERRO - Divisao por Zero!");
          registro("DIVISAO POR ZERO",01);
     }
    return result;
}
////////////////////////////////////////////////////////////////////////
template <class T> int excecoes<T>::isNegativeSQR(T numero){
 int result=0;
 try{
        if(numero<0){
            throw(erro());
            result=0;
        }
        else
           result= 1;
  }
  catch (excecoes::erro){
     Mensagem("ERRO - Raiz Negativa!");
     registro("RAIZ NEGATIVA",02);

    }
return result;
}

///////////////////////////////////////////////////////////////////
//Ta bugada
template <class T> int excecoes<T>::isNumber(T sequencia){ /*implementa��o da verifica��o de Numero*/
     int result=0;
 try {
        int i=0, cont=0;
        int tam = sequencia.size();
       while(i<tam){
          if(isdigit(sequencia[i])){
            cont++;
          }
          i++;
        }
        if (cont!=tam){
          throw (erro());
          result= 0;
        }
        else result= 1;

     } // final do bloco TRY
     catch (excecoes::erro){
          Mensagem("ERRO - Nao e  Digito!");
          registro("NAO E DIGITO",03);

     }
     return result;
}

template <class T> int excecoes<T>::isWord(T sequencia){ /*implementa��o da verifica��o de Numero*/
     int result=0;
 try {
        int i=0, cont=0;
        int tam = sequencia.size();
        while(i<tam){
          if(isalpha(sequencia[i])){
            cont++;
          }
          i++;
        }
        if (cont!=tam){
          throw (erro());
          result=0;
        }
        else
          result=1;
     } // final do bloco TRY
     catch (excecoes::erro){
          Mensagem("ERRO - Nao e caracater!");
          registro("NAO E CARACTER",04);
     }
     return result;
}

template <class T> int excecoes<T>::isIndexInvalid(T vetor[], T tam, T posicao){ /*implementa��o de indice*/
     int result=0;
    try {
        if(posicao>tam-1){
            throw(erro());
            result=0;
        }else{ result=1;}

        }
         catch (excecoes::erro){
              Mensagem("ERRO - Acesso de posicao invalida do vetor!");
               registro("ARRAY OUT OF INDEX",06);
        }
        return result;
}




template <class T> int excecoes<T>::isDate(T dia, T mes, T ano){ /*implementa��o da verifica��o de Numero*/
     int result=0;
    try {
       if ((dia >= 1 && dia <= 31) && (mes >= 1 && mes <= 12) && (ano >= 1900 && ano <= 2100)) //verifica se os numeros sao validos
        {
            if ((dia == 29 && mes == 2) && ((ano % 4) == 0)) //verifica se o ano e bissexto
            {
                return 1;
            }
            if (dia <= 28 && mes == 2) //verifica o mes de feveireiro
            {
                return 1;
            }
            if ((dia <= 30) && (mes == 4 || mes == 6 || mes == 9 || mes == 11)) //verifica os meses de 30 dias
            {
                return 1;
            }
            if ((dia <=31) && (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes ==8 || mes == 10 || mes == 12)) //verifica os meses de 31 dias
            {
                result= 1;
            }
            else
            {
                throw(erro());
                result= 0;
            }
      }
       else
           {
               throw(erro());
                result= 0;
           }
     } // final do bloco TRY
     catch (excecoes::erro){
          Mensagem("ERRO - Nao e uma data valida!");
          registro("DATA INVALIDA",05);
     }
     return  result;
}


////////////////////////////////////////////////////////////////////////////

template <class T> T* excecoes<T>::alocation(T *ptr){
 try {

       if (*ptr = 0) {
            throw (erro());
       return NULL;
       }else {
            ptr = new (nothrow) T;
            return ptr;
        }
     } // final do bloco TRY
     catch (excecoes::erro){
          Mensagem("ERRO - ponteiro nao alocado!");
         registro("ALOCACAO",07);

     }


}

template <class T> T* excecoes<T>::teste_bad_alloc(T *ptr){
    try
    {
        while(true)
        {
            ptr = new int[100000];
        }
    }
    catch(bad_alloc)
    {   ptr=NULL;
        Mensagem("ERRO - Bad Alloc!");
        registro("Bad Alloc",8);
    }
    return 0;
}
////////////////////////////////////////////////////////////////////////
template <class T> void excecoes<T>::teste_invalid_argument(){
    try
        {
        // bitset constructor throws an invalid_argument if initialized
        // with a string containing characters other than 0 and 1
        std::bitset<5> mybitset (std::string("01234"));
        }
        catch (const std::invalid_argument& ia) {
        Mensagem("ERRO - Invalid Argument!");
        registro("ERRO - Invalid Argument!",9);
        }
}

////////////////////////////////////////////////////////////////////////
template <class T> void excecoes<T>::teste_overflow(){
    try
        {
            // template based
            bitset<100> bitset;
            bitset[99] = 1;
            bitset[0] = 1;
            // to_ulong(), converts a bitset object to the integer that would generate the sequence of bits

            unsigned long Test = bitset.to_ulong();
        }//FIM TRY
        catch(exception &err)
        {
            Mensagem("ERRO - Overflow!");
            registro("ERRO - Overflow",10);
        }

}
