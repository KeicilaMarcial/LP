// Copyright (c) 2005-2009 Jaroslav Gresula
//
// Distributed under the MIT license (See accompanying file
// LICENSE.txt or copy at http://jagpdf.org/LICENSE.txt)
//


#ifndef __OBJECT_TYPE_H__
#define __OBJECT_TYPE_H__

namespace jag { namespace pdf
{

enum ObjectType
{
    PDFOBJ_UNKNOWN
};

}} //namespace jag::pdf

#endif //__OBJECT_TYPE_H__
