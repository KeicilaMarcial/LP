// Copyright (c) 2005-2009 Jaroslav Gresula
//
// Distributed under the MIT license (See accompanying file
// LICENSE.txt or copy at http://jagpdf.org/LICENSE.txt)
//


#ifndef PRECOMPILED_JG2253_H__
#define PRECOMPILED_JG2253_H__

#if defined(JAG_PRECOMPILED_HEADERS)

#include <core/generic/pch_common.h>

#endif


#endif // PRECOMPILED_JG2253_H__
/** EOF @file */
