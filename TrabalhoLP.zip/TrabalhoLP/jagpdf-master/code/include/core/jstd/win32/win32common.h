// Copyright (c) 2005-2009 Jaroslav Gresula
//
// Distributed under the MIT license (See accompanying file
// LICENSE.txt or copy at http://jagpdf.org/LICENSE.txt)
//


#include <windows.h>

namespace jag { namespace jstd
{

wchar_t const* format_win32_message(DWORD err);

}} // namespace jag::jstd
