#include<stdio.h>
#include<stdlib.h>


main(){
    int i=0,n=7,modulo=0;
    while(i<9){
       printf("Digite um numero\n");

       printf("Modulo de %d",--n)  ;
       i++;
    }


}
