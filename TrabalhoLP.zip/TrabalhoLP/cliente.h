#include "excecoes.h"
#include<math.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/*Variaveis Globais*/
int numerador=0, denominador=0,result=0,numero=0;
string sequencia;
excecoes <float> EX;
excecoes <string> EX1;
excecoes <string> EX2;
excecoes <int> EX3;
excecoes <int*>EX4;
excecoes <int>EX5;
excecoes <int>EX6;

void opcao(int op){
  switch(op){
  	case 1:
  		cout <<"Digite o numerador:\n";
        cin >>numerador;
        cout <<"Digite o denominador:\n";
        cin >>denominador;
        if((EX.isDivByZero(denominador))==1){
                result = numerador/denominador;
                cout<<"\nResultado: "<<result<<"\n"<<endl;
        }

    system("pause");
    break;
  	case 2:
        cout<<"\nDigite um numero\n";
        cin>>numero;
         if(EX3.isNegativeSQR(numero)==1){
            float result2 = sqrt(numero);
            cout<<"\nResultado: "<<result2<<"\n"<<endl;
        }
         system("pause");
    break;
  	case 3:
     // cin.ignore(); // limpa o buffer
      fflush(stdin);
  		cout<<"Digite uma sequencia:  ";
       cin>>sequencia;
  		if(EX1.isNumber(sequencia)==1){
        cout<<"\n A sequencia Digitada : "<<sequencia<<" e digito\n "<<endl;
      }
     system("pause");
  	break;
  	case 4:
            //cin.ignore(); // limpa o buffer
             fflush(stdin);
            cout<<"\nDigite uma palavra\n";
            getline(cin,sequencia);
            if(EX1.isWord(sequencia)==1){
        cout<<"\n A sequencia Digitada : "<<sequencia<<" e de caracteres\n "<<endl;
      }
       system("pause");
  	break;
  	case 5:
  	    int dia_ex5, mes_ex5, ano_ex5;
  	     fflush(stdin);
  	   // cin.ignore(); //limpa o buffer
        cout<<"\nDigita uma data:\n";
        cout<<"\nDigite o dia:\t";
        cin>>dia_ex5;
        cout<<"\nDigite o mes:\t";
        cin>>mes_ex5;
        cout<<"\nDigite o ano:\t";
        cin>>ano_ex5;
        EX5.isDate(dia_ex5, mes_ex5, ano_ex5);
     system("pause");
  	break;
  	case 6:{
  	    int posicao;
  	    int tam=5;
  	    int vetor[tam];
        cout<<"Teste com vetor tamnho: "<<tam;
        cout<<"\nDigite a posicao que deseja acessar:\n";
        cin>>posicao;
        if(EX6.isIndexInvalid(vetor, tam, posicao)==1){
            cout<<"Posicao Valida\n";
        }
         system("pause");
    break;}
    case 7:
    int *ptr;
       cout<<"\nDigite um numero\n";
        cin>>numerador;
                ptr=&numerador;
         if(EX3.alocation(ptr)){

        }
         system("pause");
    break;

    case 8:
            //TESTE BAD ALLOC
            int *teste;
            EX6.teste_bad_alloc(teste);
            system("pause");
            break;
     case 9:
        EX6.teste_invalid_argument();
         system("pause");
        break;
    case 10:
        EX6.teste_overflow();
         system("pause");
        break;
  }

}

void menu(){
    int op;
	  while(op!=0){
	  	cout<<"===================Menu Cliente====================\n(1)-Divisao Por Zero\n(2)-Raiz Negativa\n(3)-Tipo Numerico\n(4)-Palavra\n(5)-Data\n(6)-Index\n(7)-Alocacao De Memoria\n(8)-Bad Alloc\n(9)-Invalid Argument\n(10)-Overflow\n(0)-Sair\n";
      cin>>op;
	  	opcao(op);
      system("cls");
	  }

}


